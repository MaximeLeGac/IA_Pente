# workshop-client

Première ébauche du client.

## Logiciel Nécessaire :
  - [Caddy HTTP](https://caddyserver.com)

## Préparation

 - ligne 24 du fichier grille.js il faut changer l'ip et le nom de chaque client dans le tableau. ça sera remplacé plus tard par un formulaire pour récupérer tout ça et le mettre en localstorage tout ça...
 - Ne pas oublier d'ajouter *Caddy* dans votre path
 
## Lancement

 - Il suffit de lancer la commande `caddy -conf=./front/CaddyFile"`
